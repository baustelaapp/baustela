# BAUSTELA v3 — funkcionalni MVP

Ovo je nastavak BAUSTELA v2. Dodano je:
- bolji mobilni/responzivni izgled
- projekti i materijali
- izračun ukupnog troška
- ispis troškovnika preko preglednika (Print / Save as PDF)
- usporedba spremljenih cijena
- admin unos cijena i izvora
- izvoz/uvoz sigurnosne kopije podataka
- jasna oznaka da je PRO naplata još demo

## Važno
Ovo je još uvijek frontend MVP. Za stvarnu online uslugu trebaju backend, baza podataka, korisnički računi, prava pristupa i siguran payment sustav. Ovaj paket ne obrađuje stvarne kartične uplate.
